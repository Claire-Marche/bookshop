<?php
ob_start('ob_gzhandler'); //démarre la bufferisation, compression du tampon si le client supporte gzip
session_start();    // Lancement de la session

require_once './php/bibli_generale.php';
require_once './php/bibli_bookshop.php';

$co = fd_bd_connect();

if (count($_POST) != 0 && (isset($_POST['addToCart']) || isset($_POST['mod']) || isset($_POST['suppr'])) && isset($_POST['id'])) {
	add_to_cart($co);
}

error_reporting(E_ALL); // toutes les erreurs sont capturées (utile lors de la phase de développement)

fd_html_debut('BookShop | Bienvenue', './styles/bookshop.css');

fd_bookshop_enseigne_entete(isset($_SESSION['cliID']),'./');

fdl_contenu($co);

fd_bookshop_pied('./');

fd_html_fin();



ob_end_flush();


// ----------  Fonctions locales au script ----------- //

/** 
 *	Affichage du contenu de la page (i.e. contenu de l'élément section)
 */
function fdl_contenu($co) {
	if (isset($_POST['addToWishlist']) || isset($_POST['removeFromWishlist'])) {
		$cliID = $_SESSION['cliID'];
		$liID = fd_bd_protect($co, $_POST['id']);
		if (isset($_POST['addToWishlist'])) {
			fd_add_to_wishlist($co, $cliID, $liID);
		} else {
			fd_remove_from_wishlist($co, $cliID, $liID);
		}
	}
	
	echo 
		'<h1>Bienvenue sur BookShop !</h1>',
		
		'<p>Passez la souris sur le logo et laissez-vous guider pour découvrir les dernières exclusivités de notre site. </p>',
		
		'<p>Nouveau venu sur BookShop ? Consultez notre <a href="./html/presentation.html">page de présentation</a> !',
	
		'<h2>Dernières nouveautés </h2>',
	
		'<p>Voici les 4 derniers articles ajoutés dans notre boutique en ligne :</p>';
		
	$derniersAjouts = get_last_books($co);

	fdl_afficher_blocs_livres($derniersAjouts);
	
	echo 
		'<h2>Top des ventes</h2>', 
		'<p>Voici les 4 articles les plus vendus :</p>';
	
	$meilleursVentes = get_best_sales($co); 
	
	fdl_afficher_blocs_livres($meilleursVentes);	
}


/** 
 *	Affichage d'une liste de livres sous la forme de blocs
 *
 *	@param 	array 	$tLivres	tableau contenant un élément (tableau associatif) pour chaque livre (id, auteurs(nom, prenom), titre)
 */
function fdl_afficher_blocs_livres($tLivres) {

	foreach ($tLivres as $livre) {
		fd_afficher_livre($livre, 'bcArticle', './');
	}
}
	
function get_last_books($co) {
	$sql = 'SELECT * 
	FROM ((livres INNER JOIN (aut_livre INNER JOIN auteurs ON al_IDAuteur = auID) ON al_IDLivre = liID) INNER JOIN editeurs ON liIDEditeur = edID) INNER JOIN
	(SELECT liID
	FROM livres
	ORDER BY liID DESC
	LIMIT 0, 4) copy ON livres.liID = copy.liID';
	$res = mysqli_query($co, $sql) or fd_bd_erreur($co, $sql);
	$ret = transform_res($co, $res);
	mysqli_free_result($res);
	return $ret;
}
//fusion both of these
function get_best_sales($co) {
	$sql = 'SELECT *
	FROM ((livres INNER JOIN (aut_livre INNER JOIN auteurs ON al_IDAuteur = auID) ON al_IDLivre = liID) INNER JOIN editeurs ON liIDEditeur = edID) INNER JOIN
	(SELECT ccIDLivre
	FROM compo_commande
	GROUP BY ccIDLivre
	ORDER BY SUM(ccQuantite) DESC
	LIMIT 0, 4) copy ON livres.liID = copy.ccIDLivre;';
	$res = mysqli_query($co, $sql) or fd_bd_erreur($co, $sql);
	$ret = transform_res($co, $res);
	mysqli_free_result($res);
	return $ret;
}
?>
