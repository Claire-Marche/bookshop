<?php
ob_start('ob_gzhandler'); //démarre la bufferisation, compression du tampon si le client supporte gzip
session_start();    // Lancement de la session

require_once '../php/bibli_generale.php';
require_once '../php/bibli_bookshop.php';

$db = fd_bd_connect();

if (!isset($_SESSION['cliID'])) {
	fd_redirige('login.php');
	ob_clean();
	exit();
}

$sql = 'SELECT coID, coDate, coHeure, liTitre, ccQuantite, liPrix
		FROM commandes, compo_commande, livres
		WHERE coID = ccIDCommande
		AND ccIDLivre = liID
		AND coIDClient = ' . $_SESSION['cliID'] . ';';
		
$order_list = mysqli_query($db, $sql) or fd_bd_erreur($db, $sql);
		
$last = 0;
$orders = array();

while ($order = mysqli_fetch_assoc($order_list)) {
	foreach ($orders as &$or) {
		if ($or['id'] == $order['coID']) {
			$or['books'][] = array('title' => $order['liTitre'], 'quantity' => $order['ccQuantite'], 'price' => $order['liPrix'], 'total' => ($order['liPrix'] * $order['ccQuantite']));
			$or['price'] += $order['liPrix'] * $order['ccQuantite'];
			continue 2; 
		}
	}
	$orders[] = array('id' => $order['coID'], 'date' => $order['coDate'], 'time' => $order['coHeure'], 'price' => ($order['liPrix'] * $order['ccQuantite']), 'books' => array(array('title' => $order['liTitre'], 'quantity' => $order['ccQuantite'], 'price' => $order['liPrix'], 'total' => ($order['liPrix'] * $order['ccQuantite']))));
}

mysqli_free_result($order_list);

error_reporting(E_ALL); // toutes les erreurs sont capturées (utile lors de la phase de développement)

fd_html_debut('BookShop | Mes commandes', '../styles/bookshop.css');

fd_bookshop_enseigne_entete(isset($_SESSION['cliID']),'../');

echo '<h2>Liste des commandes</h2>';

if (empty($orders)) {
	echo '<p>Vous n\'avez encore effectué aucune commande.</p>';
} else {
	foreach ($orders as $order) {
		$size_hours = (strlen($order['time']) == 4 ? 2 : 1);
		echo '<h3>Commande du ', date_format(date_create_from_format('Ymd', htmlentities($order['date'])), 'j/m/y'), ' à ', htmlentities(substr($order['time'], 0, $size_hours)), ':', htmlentities(substr($order['time'], $size_hours)), ' :</h3>',
		'<table class="order">',
			'<tr>',
				'<th>Titre</th>',
				'<th>Prix unitaire</th>', 
				'<th>Quantité</th>',
				'<th>Prix total de l\'article</th>',
			'</tr>';
		
		foreach ($order['books'] as $item) {
			echo '<tr>',
				'<td>', htmlentities($item['title']), '</td>',
				'<td>', htmlentities($item['price']), '&euro;</td>',
				'<td>', htmlentities($item['quantity']), '</td>',
				'<td>', htmlentities($item['total']), '&euro;</td>',
			'<tr>';
		}
		
		echo '<tr>',
			'<td colspan="3">Prix total :</td>',
			'<td>', htmlentities($order['price']), '&euro;</td>',
		'</tr></table>';
			
	}
}

fd_bookshop_pied('../');

fd_html_fin();

mysqli_close($db);

ob_end_flush();

?>