<?php

/*********************************************************
 *        Bibliothèque de fonctions spécifiques          *
 *               à l'application BookShop                *
 *********************************************************/

 
 // constantes utilisées pour initialiser certains champs de la table client lors de l'inscription d'un utilisateur
 define('FD_INVALID_STRING', 'INVALID'); //utilisé pour les champs adresse, ville et pays
 define('FD_INVALID_CODE_POSTAL', 0); //utilisé pour le code postal
 
 // Nombre d'années affichées pour la date de naissance du formulaire d'inscription 
 define('NB_ANNEES_DATE_NAISSANCE', 121);

/**
 *	Fonction affichant le canevas général de l'application BookShop 
 *
 *	Affiche bloc page, entête et menu de navigation, enseigne, ouverture du bloc de contenu.
 *
 *  @param 	boolean		$connecte	Indique si l'utilisateur est connecté ou non.
 *	@param 	string		$prefix		Prefixe des chemins vers les fichiers du menu (usuellement "./" ou "../").
 */
function fd_bookshop_enseigne_entete($connecte,$prefix) {
	echo 
		'<div id="bcPage">',
	
		'<aside>',
			'<a href="http://www.facebook.com" target="_blank"></a>',
			'<a href="http://www.twitter.com" target="_blank"></a>',
			'<a href="http://plus.google.com" target="_blank"></a>',
			'<a href="http://www.pinterest.com" target="_blank"></a>',
		'</aside>',
		
		'<header>';
	
	fd_bookshop_menu($connecte,$prefix);
	echo 	'<img src="', $prefix,'images/soustitre.png" alt="sous titre">',
		'</header>',
		'<section>';
}


/**
 *	Fonction affichant le menu de navigation de l'application BookShop 
 *
 *  @param 	boolean		$connecte	Indique si l'utilisateur est connecté ou non.
 *	@param 	string		$prefix		Prefixe des chemins vers les fichiers du menu (usuellement "./" ou "../").
 */
function fd_bookshop_menu($connecte, $prefix) {		
	echo 
		'<nav>',	
			'<a href="', $prefix, 'index.php"></a>';
	
	$liens = array( 'recherche' => array( 'pos' => 1, 'title' => 'Effectuer une recherche'),
					'panier' => array( 'pos' => 2, 'title' => 'Voir votre panier'),
					'liste' => array( 'pos' => 3, 'title' => 'Voir une liste de cadeaux'),
					'compte' => array( 'pos' => 4, 'title' => 'Consulter votre compte'),
					'deconnexion' => array( 'pos' => 5, 'title' => 'Se déconnecter'));
					
	if (!$connecte){
		unset($liens['compte']);
		unset($liens['deconnexion']);
		$liens['recherche']['pos']++;
		$liens['panier']['pos']++;
		$liens['liste']['pos']++;
		/*TODO : 	- peut-on implémenter les 3 incrémentations ci-dessus avec un foreach ? */
		$liens['login'] = array( 'pos' => 5, 'title' => 'Se connecter');
		/* Debug :
		echo '<pre>', print_r($liens, true), '</pre>';
		exit;*/
	}
	
	foreach ($liens as $cle => $elt) {
		echo
			'<a class="lienMenu position', $elt['pos'], '" href="', $prefix, 'php/', $cle, '.php" title="', $elt['title'], '"></a>';
	}
	echo '</nav>';
}


/**
 *	Fonction affichant le pied de page de l'application BookShop.
 */
function fd_bookshop_pied($prefix) {
	echo 
		'</section>', // fin de la section
		'<footer>', 
			'BookShop &amp; Partners &copy; ', date('Y'), ' - ',
			'<a href="', $prefix, 'php/apropos.php">A propos</a> - ',
			'<a href="', $prefix, 'php/confident.php">Emplois @ BookShop</a> - ',
			'<a href="', $prefix, 'php/conditions.php">Conditions d\'utilisation</a>',
		'</footer>',
	'</div>'; // fin bcPage
}


/**
 *	Affichage d'un livre.
 *
 *	@param	array		$livre 		tableau associatif des infos sur un livre (id, auteurs(nom, prenom), titre, prix, pages, ISBN13, edWeb, edNom)
 *	@param 	string 		$class		classe de l'élement div  : bcResultat ou bcArticle ou details ou cart-item
 *  @param 	String		$prefix		Prefixe des chemins vers le répertoire images (usuellement "./" ou "../").
 */
function fd_afficher_livre($livre, $class, $prefix) {
	echo 
		'<div class="', $class, '">';   
			if ($class !== 'cart-item') {
				//On conserve l'ancienne query string, pour que le rechargement de la page soit correct (recherche conservée par exemple)
				echo '<form method="POST" action="', $_SERVER['PHP_SELF'], (isset($_SERVER['QUERY_STRING']) && !empty($_SERVER['QUERY_STRING']) ? '?' . $_SERVER['QUERY_STRING'] : ''), '">',
							'<input type="hidden" value="', $livre['id'], '" name="id">';
				 //On conserve de même, l'ancien contenu de la variable POST pour la même raison
				 foreach ($_POST as $name => $value) {
					//Néanmoins, on ne conserve pas une précèdente tentative d'ajout / de suppression d'article au panier ou à la wishlist, ceci ayant déjà été traité 
					if (!($name == "id" || $name == "addToCart" || $name == "removeFromWishlist" || $name == "addToWishlist")) {
						echo '<input type="hidden" value="' . $value . '" name="' . $name . '">';
					}
				 }
						echo '<input type="submit" class="', ($class != 'details' ? 'addToCart' : $class) ,'" value="Ajouter au panier" name="addToCart" title="Ajouter au panier">',
					'</form>';
			}
			if (isset($_SESSION['cliID'])) {
				//On conserve l'ancienne query string, pour que le rechargement de la page soit correct (recherche conservée par exemple)
				echo '<form method="POST" action="' . $_SERVER['PHP_SELF'] . (isset($_SERVER['QUERY_STRING']) && !empty($_SERVER['QUERY_STRING']) ? '?' . $_SERVER['QUERY_STRING'] : ''),  '">' .
						 '<input type="hidden" value="' . $livre['id'] . '" name="id">';
				 //On conserve de même, l'ancien contenu de la variable POST pour la même raison
				 foreach ($_POST as $name => $value) {
					//Néanmoins, on ne conserve pas une précèdente tentative d'ajout / de suppression d'article au panier ou à la wishlist, ceci ayant déjà été traité 
					if (!($name == "id" || $name == "addToCart" || $name == "removeFromWishlist" || $name == "addToWishlist")) {
						echo '<input type="hidden" value="' . $value . '" name="' . $name . '">';
					}
				 }
				 if ($livre['isInWishList']) {
					echo '<input type="submit" class="', ($class != 'details' && $class != 'cart-item' ? 'removeFromWishlist' : $class), '" value="Retirer de la liste" name="removeFromWishlist" title="Supprimer de la liste de cadeaux">';
				 } else {
					echo '<input type="submit" class="', ($class != 'details' && $class != 'cart-item' ? 'addToWishlist' : $class), '" value="Ajouter à la liste" name="addToWishlist" title="Ajouter à la liste de cadeaux">';
				 }
				echo '</form>';
			}
			if ($class !== 'details') {
				echo '<a href="', $prefix, 'php/details.php?article=', $livre['id'], '" title="Voir détails">';
			}
			echo '<img src="', $prefix, 'images/livres/', $livre['id'], '_mini.jpg" alt="', 
				fd_protect_sortie($livre['titre']),'">';
			if ($class !== 'details') {
				echo '</a>';
			}
			if ($class == 'bcResultat' || $class == 'details'){
				echo	'<strong>', fd_protect_sortie($livre['titre']), '</strong> <br>',
					'Ecrit par : ';
			}
			elseif($class == 'bcArticle'){
				echo '<br>';
			} elseif ($class == 'cart-item') {
				echo '<strong>', fd_protect_sortie($livre['titre']), '</strong> <br>';
			}

			$i = 0;
			foreach ($livre['auteurs'] as $auteur) {
				$supportLien = $class == 'bcResultat' ? "{$auteur['prenom']} {$auteur['nom']}" : "{$auteur['prenom']{0}}. {$auteur['nom']}";
				if ($i > 0) {
					echo ', ';
				}
				$i++;
				echo '<a href="', $prefix, 'php/recherche.php?type=auteur&quoi=', urlencode($auteur['nom']), '">',fd_protect_sortie($supportLien), '</a>';
			}
			if ($class == 'bcResultat' || $class == 'details'){		
				echo	'<br>Editeur : <a class="lienExterne" href="http://', fd_protect_sortie($livre['edWeb']), '" target="_blank">', fd_protect_sortie($livre['edNom']), '</a><br>',
						'Prix : ', $livre['prix'], ' &euro;<br>',
						'Pages : ', $livre['pages'], '<br>',
						'ISBN13 : ', fd_protect_sortie($livre['ISBN13']);
			}
			elseif($class == 'bcArticle' || $class == 'cart-item'){
				echo 
					'<br>';
					if ($class == 'bcArticle') {
						echo '<strong>', fd_protect_sortie($livre['titre']), '</strong>';
					}
					if ($class == 'cart-item') {
						echo 'Prix : ', $livre['prix'], ' &euro;';
					}
					if ($class == 'cart-item') {
						echo '<div>',
								'<form method="POST" action="panier.php">',
									'<input type="hidden" value="', $livre['id'], '" name="id">',
									'<label for="quantity">Quantité :</label>',
									'<input type="number" value="', $livre['quantity'], '" name="quantity" id="quantity">',
									'<input type="submit" value="Modifier" name="mod">',
								'</form>',
							'</div>',
							'<div>Prix total : ', $livre['prix'] * $livre['quantity'], '&euro;</div>',
							'<form method="POST" action="panier.php">',
									'<input type="hidden" value="', $livre['id'], '" name="id">',
									'<input type="submit" value="Supprimer" name="suppr">',
							'</form>';
					}
			}
			
			if ($class == 'details') {
				echo '<br>Résumé : <div>', $livre['resume'], '</div>';
			}
	echo '</div>';
}

/**
 *	Ajout d'un livre à la liste de cadeaux.
 *
 *	@param	Connexion	$bd		connexion à la base de données
 *  @param  int         $cliID  identifiant du client
 *  @param  int			$liID	identifiant du livre
 */
function fd_add_to_wishlist($bd, $cliID, $liID) {
	$sql = "INSERT IGNORE INTO listes
			VALUES ($cliID, $liID)";
			
	mysqli_query($bd, $sql) or fd_bd_erreur($bd, $sql);
}

/**
 * Suppression d'un livre de la liste de cadeaux.
 *
 *	@param	Connexion	$bd		connexion à la base de données
 *  @param  int         $cliID  identifiant du client
 *  @param  int			$liID	identifiant du livre
 */
function fd_remove_from_wishlist($bd, $cliID, $liID) {
	$sql = "DELETE FROM listes
			WHERE listIDClient = $cliID AND listIDLivre = $liID";
			
	mysqli_query($bd, $sql) or fd_bd_erreur($bd, $sql);
}

/**
 *	Vérification de si un livre est dans la liste de cadeaux.
 *
 *	@param	Connexion	$bd		connexion à la base de données
 *  @param  int			$liID	identifiant du livre
 *
 *	@return boolean		présence de l'article dans la liste de cadeaux
 */
function fd_article_is_in_wishlist($bd, $liID) {
	$cliID = $_SESSION['cliID']; //la fonction ne peut être appelée que si l'utilisateur est connecté
	
	$sql = "SELECT listIDLivre
			FROM listes
			WHERE listIDClient = $cliID AND listIDLivre = $liID";
			
	$res = mysqli_query($bd, $sql) or fd_bd_erreur($bd, $sql);
	
	$is_in_wishlist = false;
	if (mysqli_fetch_assoc($res)) {
		$is_in_wishlist = true;
	}
	
	mysqli_free_result($res);
	
	return $is_in_wishlist;
}

/** 
 *	Renvoie un tableau contenant les pages du site bookshop
 *
 * 	@return array pages du site
 */
function get_pages_bookshop() {
	return array('index.php', 'login.php', 'inscription.php', 'deconnexion.php', 'recherche.php', 'presentation.html');
}

/**
 *  Transforme le résultat d'une requête en tableau associatif prêt à l'affichage
 *  
 *	@param  Connexion $bd  connexion à la base de données
 *  @param  Object    $res résultat d'une requête SELECT
 *
 *  @return array  le tableau associatif qui récapitule les résultats 
 */
function transform_res($bd, $res) {
	$ret = array();
	$pos = 0;
	while ($t = mysqli_fetch_assoc($res)) {
		foreach ($ret as $num => $item) {
			if ($t['liID'] === $item['id']) {
				$ret[$num]['auteurs'][] = array('prenom' => $t['auPrenom'], 'nom' => $t['auNom']);
				continue 2;
			}
		}
		
		$isInWishList = false;
		if (isset($_SESSION['cliID'])) {
			$isInWishList = fd_article_is_in_wishlist($bd, $t['liID']);
		}
		$ret[$pos++] = array('id' => $t['liID'], 
						'titre' => $t['liTitre'],
						'edNom' => $t['edNom'],
						'edWeb' => $t['edWeb'],
						'resume' => $t['liResume'],
						'pages' => $t['liPages'],
						'ISBN13' => $t['liISBN13'],
						'prix' => $t['liPrix'],
						'auteurs' => array(array('prenom' => $t['auPrenom'], 'nom' => $t['auNom'])),
						'isInWishList' => $isInWishList
					);
	}
	
	return $ret;
}

/**
 *  Effectue le traitement de POST et ajoute, modifie ou supprime l'article contenu dans POST dans le panier de session
 *  
 *  @param  Connexion $co       Connexion à la base de données
 *  @global array     $_SESSION session courante
 *  @global array     $_POST    formulaire dans le corps de la requête HTTP
 */
function add_to_cart($co) {
	if (isset($_POST['addToCart'])) {
		$add = true;
		if (isset($_SESSION['cart'])) {
			$index = -1;
			foreach($_SESSION['cart'] as $num => $item) {
				if ($item['id'] == $_POST['id']) {
					$add = false;
					$index = $num;
					break;
				}
			}
			if (!$add) {
				$_SESSION['cart'][$index]['quantity']++;
			}
		}
		if ($add /*&& is_int($_POST['id'])*/) {
			$sql = 'SELECT liID
			FROM livres
			WHERE liID = ' . $_POST['id'] . ';';
			$res = mysqli_query($co, $sql) or fd_bd_erreur($co, $sql);
			if (mysqli_num_rows($res) != 0) {
				$_SESSION['cart'][] = array('id' => $_POST['id'], 'quantity' => 1);
			}
			mysqli_free_result($res);
		}
	} elseif (isset($_POST['suppr'])) {
		if (isset($_SESSION['cart'])) {
			$index = -1;
			$size = count($_SESSION['cart']);
			foreach ($_SESSION['cart'] as $num => $item) {
				if ($item['id'] == $_POST['id']) {
					$index = $num;
				}
			}
			if ($index != -1) {
				for ($i = $index; $i < $size - 1; $i++) {
					$_SESSION['cart'][$i] = $_SESSION['cart'][$i + 1];
				}
				unset($_SESSION['cart'][$size - 1]);
			}
		}
	} elseif (isset($_POST['mod'])) {
		if (isset($_SESSION['cart'])) {
			$index = -1;
			foreach ($_SESSION['cart'] as $num => $item) {
				if ($item['id'] == $_POST['id']) {
					$index = $num;
					break;
				}
			} 
			if ($index != -1) {
				$_SESSION['cart'][$index]['quantity'] = $_POST['quantity'];
				
				if ($_SESSION['cart'][$index]['quantity'] <= 0) {
					$size = count($_SESSION['cart']);
					for ($i = $index; $i < $size - 1; $i++) {
						$_SESSION['cart'][$i] = $_SESSION['cart'][$i + 1];
					}
					unset($_SESSION['cart'][$size - 1]);
				}
			}
		}
	}
}

/**
 * Recherche l'indice de l'ID d'un livre dans l'ensemble des livres
 *
 * @param array $books ensemble des livres
 * @param int   $liID  ID du livre recherché
 *
 * @return		indice du livre dans le tableau (-1 si inexistant)
 */
function fd_search_liID($books, $liID) {
	foreach ($books as $i => $book) {
		if ($book['id'] == $liID) {
			return $i;
		}
	}
	return -1;
}

?>
