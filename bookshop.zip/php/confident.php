<?php
ob_start('ob_gzhandler'); //démarre la bufferisation, compression du tampon si le client supporte gzip
session_start();    // Lancement de la session

require_once '../php/bibli_generale.php';
require_once '../php/bibli_bookshop.php';

error_reporting(E_ALL); // toutes les erreurs sont capturées (utile lors de la phase de développement)

fd_html_debut('BookShop | Emplois', '../styles/bookshop.css');

fd_bookshop_enseigne_entete(isset($_SESSION['cliID']),'../');

fdl_contenu();

fd_bookshop_pied('../');

fd_html_fin();

ob_end_flush();

/**
 *	Affichage du contenu de la page
 */
function fdl_contenu() {
	echo '<h1>Emplois</h1>',
		 '<h2>Offres d\'emplois</h2>',
			'<p>Aucune offre n\'est disponible pour le moment.</p>',
		 '<h2>Candidature spontanée</h2>',
			'<p>Si vous souhaitez pouvoir apporter quelque chose à l\'équipe Bookshop, 
			contactez nous à l\'adresse mail <a href="mailto:candidatures@bookshop.fr">candidatures@bookshop.fr</a>.</p>';
}
?>