<?php
require_once 'bibli_generale.php';

// Reprise de la session
session_start();

// Arr�t de la session et redirection vers index.php
fd_exit_session();
?>