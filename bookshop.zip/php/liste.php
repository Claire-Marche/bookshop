<?php
ob_start('ob_gzhandler'); //démarre la bufferisation, compression du tampon si le client supporte gzip
session_start();    // Lancement de la session

require_once '../php/bibli_generale.php';
require_once '../php/bibli_bookshop.php';

error_reporting(E_ALL); // toutes les erreurs sont capturées (utile lors de la phase de développement)

$valueEmail = "";

if ($_GET){
	//Si $_GET existe, l'adresse e-mail y est forcément dedans
	$valueEmail = fdl_control_get();
}
else if ($_POST){
	$valueEmail = fdl_control_post();
}

fd_html_debut('BookShop | Liste', '../styles/bookshop.css');

fd_bookshop_enseigne_entete(isset($_SESSION['cliID']),'../');

fdl_contenu($valueEmail);

fd_bookshop_pied('../');

fd_html_fin();

ob_end_flush();


/**
 *	Affichage du contenu de la page (liste de voeux)
 *	@param 	str $valueEmail valeur de l'adresse mail dont il faut afficher la liste
 */
function fdl_contenu($valueEmail) {
	$bd = fd_bd_connect();
	
	if ((isset($_POST['addToCart']) || isset($_POST['suppr'])) && isset($_POST['id'])) {
		add_to_cart($bd);
	}
	
	if (isset($_POST['addToWishlist']) || isset($_POST['removeFromWishlist'])) {
		$cliID = $_SESSION['cliID'];
		$liID = fd_bd_protect($bd, $_POST['id']);
		if (isset($_POST['addToWishlist'])) {
			fd_add_to_wishlist($bd, $cliID, $liID);
		} else {
			fd_remove_from_wishlist($bd, $cliID, $liID);
		}
	}
	
	if ($valueEmail == "") {
		if (isset($_SESSION['cliID'])) {
			$id = $_SESSION['cliID'];

			$sql = "SELECT liID, liTitre, liPrix, liPages, liISBN13, edNom, edWeb, auNom, auPrenom
					FROM (((((clients INNER JOIN listes ON cliID = listIDClient) 
						 INNER JOIN livres ON listIDLivre = liID) 
						 INNER JOIN editeurs ON liIDEditeur = edID)
						 INNER JOIN aut_livre ON al_IDLivre = liID)
						 INNER JOIN auteurs ON al_IDAuteur = auID)
					WHERE cliID = $id";
			
			$res = mysqli_query($bd, $sql) or fd_bd_erreur($bd, $sql);
			
			fdl_afficher_liste($bd, $res, $valueEmail);
			
			mysqli_free_result($res);

		} else {
			echo '<p class="erreur"> Ici s\'afficherait votre liste de cadeaux personnalisée si vous êtiez connecté. <br>
				 Néanmoins, vous pouvez toujours consulter celle des autres par simple recherche d\'adresse email.</p>';
		}
	} else {
		$cliEmail = fd_bd_protect($bd, $valueEmail);
		
		$sql = "SELECT cliNomPrenom, liID, liTitre, liPrix, liPages, liISBN13, edNom, edWeb, auNom, auPrenom
					FROM (((((listes INNER JOIN livres ON listIDLivre = liID) 
						 INNER JOIN editeurs ON liIDEditeur = edID)
						 INNER JOIN aut_livre ON al_IDLivre = liID)
						 INNER JOIN auteurs ON al_IDAuteur = auID)
						 RIGHT OUTER JOIN clients ON cliID = listIDClient)
					WHERE cliID IN (SELECT cliID
								   FROM clients
								   WHERE cliEmail = '$cliEmail')";
		
		$res = mysqli_query($bd, $sql) or fd_bd_erreur($bd, $sql);	
		$nb_res = mysqli_num_rows($res);
		
		if ($nb_res == 0) {
			echo '<p class="erreur"> L\'adresse email ne correspond à aucun utilisateur enregistré. </p>';
		} else {
			fdl_afficher_liste($bd, $res, $valueEmail);
		}
		
		mysqli_free_result($res);
		
		if (isset($_SESSION['cliID'])) {
			echo '<form action="liste.php" method="post">',
					'<p class="centered">',
						fd_form_input(FD_Z_SUBMIT, 'btnRetour', 'Votre liste'),
					'</p>',
				 '</form>';
		}
	}
	echo '<form action="liste.php" method="post">',
			'<p class="centered">Rechercher une liste <input type="email" name="email" value="', fd_protect_sortie($valueEmail), '">', 
				'<input type="submit" value="Rechercher" name="btnRechercher">
			</p>
		  </form>'; 
	
	
	mysqli_close($bd);
}

function fdl_control_get() {
	return (isset($_GET['email']) ? $_GET['email'] : '');
}

function fdl_control_post() {
	return (isset($_POST['email']) ? $_POST['email'] : '');
}

/**
 * Affiche la liste de souhait demandée
 *
 * @param Connexion $bd  	Connexion à la base de données
 * @param Object    $res 	Résultat de la requête demandée
 * @param String	$email  Valeur de l'adresse mail de l'utilisateur dont la liste est demandée
 */
function fdl_afficher_liste($bd, $res, $email) {
	// mise en place de la pagination
	$paging = 5;
	$pos = isset($_GET['pos']) ? $_GET['pos'] : -1;
	$total = isset($_GET['total']) ? $_GET['total'] : -1;

	if (($total < 0 || $pos < 0) || (!($pos >= 0 && $pos < $total)))  {
		$total = $pos = 0;
	}
	
	//Vérification de si la liste est celle de l'utilisateur, donc que $email == ""
	$user_list = ($email == "");
	
	if ($user_list) {
		echo '<h3>Votre liste de cadeaux</h3>';
	}
	
	$books = array();
	
	$count = 0; // limitation des résultats
	while ($t = mysqli_fetch_assoc($res)) {
		if (!$user_list && $count == 0) {
			echo '<h3>Liste de cadeaux de ', fd_protect_sortie($t['cliNomPrenom']), '</h3>';
		}
		if (!$t['liID']) {
			//la liste est vide
			break;
		}
		$i = fd_search_liID($books, $t['liID']); // indice du livre
		if ($i == -1) { // si le livre n'est pas déjà dans le tableau
			$count++;
			if ($count - $pos > $paging || $count <= $pos) {
				$books[] = array(
								'id' => $t['liID']
							);
				continue;
			}
			
			//Vérification de la présence du livre dans la liste de l'utilisateur connecté			
			$isInWishList = false;
			if ($user_list) {
				//Si on affiche la liste de l'utilisateur connecté, la vérification est inutile
				$isInWishList = true;
			} else if (isset($_SESSION['cliID'])) {
				$isInWishList = fd_article_is_in_wishlist($bd, $t['liID']);
			}
			
			$books[] = array(	
							'id' => $t['liID'], 
							'titre' => $t['liTitre'],
							'edNom' => $t['edNom'],
							'edWeb' => $t['edWeb'],
							//'resume' => $t['liResume'],
							'pages' => $t['liPages'],
							'ISBN13' => $t['liISBN13'],
							'prix' => $t['liPrix'],
							'auteurs' => array(array('prenom' => $t['auPrenom'], 'nom' => $t['auNom'])),
							'isInWishList' => $isInWishList
						);
		} else {
			$books[$i]['auteurs'][] = array('prenom' => $t['auPrenom'], 'nom' => $t['auNom']);
		}
	}
	
	if ($total == 0) {
		$total = $count;
	}
	
	//Teste d'existence de livre dans la liste de cadeaux
	if ($total == 0) {
		echo '<p class="erreur"> La liste de cadeaux est vide. </p>';
		return;
	}
	
	// interface de changement de page
	$search = '';
	if ($email != '') {
		$search = 'email=' . urlencode($email);
	}
	fd_paging_interface($search, $paging, $pos, $total);
	
	
	foreach ($books as $t) {
		if (isset($t['titre'])) { // si le livre a été ajouté uniquement pour le dénombrement, on ne l'affiche pas
			fd_afficher_livre($t, 'bcResultat', '../');
		}
	}
}