<?php
ob_start('ob_gzhandler'); //démarre la bufferisation, compression du tampon si le client supporte gzip
session_start();    // Lancement de la session

require_once '../php/bibli_generale.php';
require_once '../php/bibli_bookshop.php';

$db = fd_bd_connect();
if (count($_POST) != 0 && (isset($_POST['addToCart']) || isset($_POST['mod']) || isset($_POST['suppr'])) && isset($_POST['id'])) {
	add_to_cart($db);
}

if (isset($_POST['addToWishlist']) || isset($_POST['removeFromWishlist'])) {
    $cliID = $_SESSION['cliID'];
    $liID = fd_bd_protect($db, $_POST['id']);
    if (isset($_POST['addToWishlist'])) {
        fd_add_to_wishlist($db, $cliID, $liID);
    } else {
        fd_remove_from_wishlist($db, $cliID, $liID);
    }
}



if (isset($_POST['buy'])) {
	if (!isset($_SESSION['cliID'])) {
		fd_redirige('login.php');
	}
	
	if (isset($_SESSION['cart']) && !empty($_SESSION['cart'])) {
		$sql = 'INSERT INTO commandes (coIDClient, coDate, coHeure)
				VALUES (' . $_SESSION['cliID'] . ', ' . date('Ymd') . ', ' . date('Gi') . ');';
		mysqli_query($db, $sql) or fd_bd_erreur($db, $sql);
		$id = mysqli_insert_id($db);
		$sql = 'INSERT INTO compo_commande (ccIDLivre, ccIDCommande, ccQuantite)
				VALUES ';
		foreach ($_SESSION['cart'] as $item) {
			$sql .= '(' . $item['id'] . ', ' . $id . ', ' . $item['quantity'] . '), ';
		}
		
		$sql = substr($sql, 0, strlen($sql) - 2);
		mysqli_query($db, $sql) or fd_bd_erreur($db, $sql);
		unset($_SESSION['cart']);
	}
}

error_reporting(E_ALL); // toutes les erreurs sont capturées (utile lors de la phase de développement)

fd_html_debut('BookShop | Mon panier', '../styles/bookshop.css');

fd_bookshop_enseigne_entete(isset($_SESSION['cliID']),'../');

echo '<h1>Mon panier</h1>';

if (isset($_SESSION['cart']) && ! empty($_SESSION['cart'])) {
	$sql = 'SELECT *
			FROM livres, auteurs, aut_livre, editeurs
			WHERE liID = al_IDLivre
			AND al_IDAuteur = auID
			AND liIDEditeur = edID
			AND (';
			
	for ($i = 0, $count = count($_SESSION['cart']); $i < $count; $i++) {
		if ($i != 0) {
			$sql .= 'OR ';
		}
		$sql .= 'liID = ' . $_SESSION['cart'][$i]['id'] . ' ';
	}
	
	$sql .= ');';
	
	$res = mysqli_query($db, $sql) or fd_bd_erreur($db, $sql);
	
	$ret = transform_res($db, $res);
	
	foreach($ret as &$book) {
		foreach ($_SESSION['cart'] as $item) {
			if ($item['id'] == $book['id']) {
				$book['quantity'] = $item['quantity'];
				continue 2;
			}
		}
	}
	
	mysqli_free_result($res);
	
	$total = 0;
	
	foreach ($ret as $item) {
        if ($total != 0) {
            echo '<hr>';
        }
		fd_afficher_livre($item, 'cart-item', '../');
		$total += $item['prix'] * $item['quantity'];
	}
	
	echo '<div id="total">Prix total : ', $total, '&euro;</div>',
	'<form method="POST" action="panier.php">',
		'<input type="submit" name="buy" value="Commander">',
	'</form>';
} else {
	echo '<p>Votre panier est encore vide ! Vous pouvez effectuer une <a href="recherche.php">recherche</a> pour un ouvrage ou un auteur, ou tout simplement consulter nos nouveautés et nos plus grands succès sur notre <a href="../index.php">page d\'accueil</a>.</p>'; 
}

fd_bookshop_pied('../');

fd_html_fin();

mysqli_close($db);

ob_end_flush();

?>