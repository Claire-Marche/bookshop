<?php
ob_start('ob_gzhandler'); //démarre la bufferisation, compression du tampon si le client supporte gzip
session_start();    // Lancement de la session

require_once '../php/bibli_generale.php';
require_once '../php/bibli_bookshop.php';

error_reporting(E_ALL); // toutes les erreurs sont capturées (utile lors de la phase de développement)
     
$valueType = 'auteur';
$valueQuoi = '';

if ($_GET){
	$valueQuoi = fdl_control_get($valueType);
}
else if ($_POST){
	$valueQuoi = fdl_control_post($valueType);
}

fd_html_debut('BookShop | Recherche', '../styles/bookshop.css');

fd_bookshop_enseigne_entete(isset($_SESSION['cliID']),'../');

fdl_contenu($valueType, $valueQuoi);

fd_bookshop_pied('../');

fd_html_fin();

ob_end_flush();


// ----------  Fonctions locales au script ----------- //

/**
 *	Contenu de la page : formulaire de recherche + résultats éventuels 
 *
 * @param   string    $valueType type de recherche (auteur ou titre)
 * @param   string    $valueQuoi partie du nom de l'auteur ou du titre à rechercher
 * @global  array     $_POST
 * @global  array     $_GET
 */
function fdl_contenu($valueType, $valueQuoi) {
	$bd = fd_bd_connect();
	
	if ((isset($_POST['addToCart']) || isset($_POST['suppr'])) && isset($_POST['id'])) {
		add_to_cart($bd);
	}
		
	if (isset($_POST['addToWishlist']) || isset($_POST['removeFromWishlist'])) {
		$cliID = $_SESSION['cliID'];
		$liID = fd_bd_protect($bd, $_POST['id']);
		if (isset($_POST['addToWishlist'])) {
			fd_add_to_wishlist($bd, $cliID, $liID);
		} else {
			fd_remove_from_wishlist($bd, $cliID, $liID);
		}
	}
	
	
	echo '<h3>Recherche par une partie du nom d\'un auteur ou du titre</h3>'; 
	
	/** 3ème version : version "formulaire de recherche" */
	echo '<form action="recherche.php" method="post">',
			'<p class="centered">Rechercher <input type="text" name="quoi" value="', fd_protect_sortie($valueQuoi), '">', 
			' dans ', 
				'<select name="type">', 
					'<option value="auteur" ', $valueType == 'auteur' ? 'selected' : '', '>auteurs</option>', 
					'<option value="titre" ', $valueType == 'titre' ? 'selected' : '','>titre</option>', 
				'</select>', 
			'<input type="submit" value="Rechercher" name="btnRechercher"></p></form>'; 
	
	if (!$valueQuoi){
        return; // ===> Fin de la fonction (ni soumission du formulaire, ni query string)
    }
	if (!isset($_GET['pos']) && mb_strlen($valueQuoi, 'UTF-8') < 2){
        echo '<p><strong>Le mot recherché doit avoir une longueur supérieure ou égale à 2</strong></p>';
		return; // ===> Fin de la fonction
	}
	
	// affichage des résultats
	
	// requête
	
	$q = fd_bd_protect($bd, $valueQuoi);

	// mise en place de la pagination
	$paging = 5;
	$pos = isset($_GET['pos']) ? $_GET['pos'] : -1;
	$total = isset($_GET['total']) ? $_GET['total'] : -1;

	if (($total < 0 || $pos < 0) || (!($pos >= 0 && $pos < $total)))  {
		$total = $pos = 0;
	}
	
	if ($valueType == 'auteur') {
        $critere = "WHERE liID in (SELECT al_IDLivre FROM aut_livre INNER JOIN auteurs ON al_IDAuteur = auID WHERE auNom LIKE '%$q%')";
	} 
	else {
		$critere = "WHERE liTitre LIKE '%$q%'";	
	}

	$sql = 	"SELECT liID, liTitre, liPrix, liPages, liISBN13, edNom, edWeb, auNom, auPrenom 
			FROM livres INNER JOIN editeurs ON liIDEditeur = edID 
						INNER JOIN aut_livre ON al_IDLivre = liID 
						INNER JOIN auteurs ON al_IDAuteur = auID 
			$critere
			";

	$res = mysqli_query($bd, $sql) or fd_bd_erreur($bd, $sql);
	
	$books = array();
	
	$count = 0; // limitation des résultats
	while ($t = mysqli_fetch_assoc($res)) {
		$i = fd_search_liID($books, $t['liID']); // indice du livre
		if ($i == -1) { // si le livre n'est pas déjà dans le tableau
			$count++;
			if ($count - $pos > $paging || $count <= $pos) {
				$books[] = array(
								'id' => $t['liID']
							);
				continue;
			}
			
			$isInWishList = false;
			if (isset($_SESSION['cliID'])) {
				$isInWishList = fd_article_is_in_wishlist($bd, $t['liID']);
			}
			
			$books[] = array(	
							'id' => $t['liID'], 
							'titre' => $t['liTitre'],
							'edNom' => $t['edNom'],
							'edWeb' => $t['edWeb'],
							//'resume' => $t['liResume'],
							'pages' => $t['liPages'],
							'ISBN13' => $t['liISBN13'],
							'prix' => $t['liPrix'],
							'auteurs' => array(array('prenom' => $t['auPrenom'], 'nom' => $t['auNom'])),
							'isInWishList' => $isInWishList
						);
		} else {
			$books[$i]['auteurs'][] = array('prenom' => $t['auPrenom'], 'nom' => $t['auNom']);
		}
	}
	
	if ($total == 0) {
		$total = $count;
	}
	
	// interface de changement de page
	$search = 'type=' . urlencode($valueType) . '&quoi=' . urlencode($q);
	fd_paging_interface($search, $paging, $pos, $total);

	foreach ($books as $t) {
		if (isset($t['titre'])) { // si le livre a été ajouté uniquement pour le dénombrement, on ne l'affiche pas
			fd_afficher_livre($t, 'bcResultat', '../');
		}
	}
    // libération des ressources
	mysqli_free_result($res);
	mysqli_close($bd);
    
	if (sizeof($books) == 0) {
		echo '<p>Aucun livre trouvé</p>';
	} 
}

/**
 *	Contrôle de la validité des informations reçues via la query string 
 *
 * En cas d'informations invalides, la session de l'utilisateur est arrêtée et il redirigé vers la page index.php
 *
 * @param   string    $valueT   type de recherche (auteur ou titre)
 * @global  array     $_GET
 *
 * @return  string       Valeur de " quoi "
 */
function fdl_control_get(&$valueT) {
	$nb_GET = count($_GET);
	($nb_GET != 2 && $nb_GET != 4) && fd_exit_session();
	
	(! isset($_GET['type']) || (($_GET['type'] != 'auteur') && ($_GET['type'] != 'titre')) || (! isset($_GET['quoi']))) && fd_exit_session();
	
	if (count($_GET) == 4) {
		((! isset($_GET['total']) || !(est_entier($_GET['total']))) || (! isset($_GET['pos']) || !(est_entier($_GET['pos'])))) && fd_exit_session();
	}
	
	$valueT = $_GET['type'] == 'auteur' ? 'auteur' : 'titre';
	
	$valueQ = trim($_GET['quoi']);
	$notags = strip_tags($valueQ);
	(mb_strlen($notags, 'UTF-8') != mb_strlen($valueQ, 'UTF-8')) && fd_exit_session();
	
	return $valueQ;
}

/**
 *	Contrôle de la validité des informations lors de la soumission du formulaire  
 *
 * En cas d'informations invalides, la session de l'utilisateur est arrêtée et il redirigé vers la page index.php
 *
 * @param   string    $valueT   type de recherche (auteur ou titre)
 * @global  array     $_POST
 *
 * @return            partie du nom de l'auteur ou du titre à rechercher            
 */
function fdl_control_post(&$valueT) {
	$nb_POST = count($_POST);
	($nb_POST != 5 && $nb_POST != 3) && fd_exit_session();
	
	//Les paramètres de recherche doivent toujours être là
	(! isset($_POST['btnRechercher']) || $_POST['btnRechercher'] != 'Rechercher') && fd_exit_session();
	(! isset($_POST['type'])) && fd_exit_session();
	($_POST['type'] != 'auteur' && $_POST['type'] != 'titre') && fd_exit_session();
	(! isset($_POST['quoi'])) && fd_exit_session();
	
	$valueT = $_POST['type'] == 'auteur' ? 'auteur' : 'titre';
		
	$valueQ = trim($_POST['quoi']);
	$notags = strip_tags($valueQ);
	(mb_strlen($notags, 'UTF-8') != mb_strlen($valueQ, 'UTF-8')) && fd_exit_session();	
		   
	if ($nb_POST == 5) {
		//Si il y a 5 variables, c'est qu'il doit y avoir une tentative d'ajout à la wishlist / au panier
		((!isset($_POST['addToCart']) && ! isset($_POST['addToWishlist']) && ! isset($_POST['removeFromWishlist'])) || ! isset($_POST['id'])) && fd_exit_session();
	}
	
	return $valueQ;
}
?>
