<?php

//Pour ajouter une adresse, vous devez en fournir toutes les composantes.

ob_start('ob_gzhandler'); //démarre la bufferisation, compression du tampon si le client supporte gzip
session_start();    // Lancement de la session

require_once 'bibli_generale.php';
require_once 'bibli_bookshop.php';

error_reporting(E_ALL); // toutes les erreurs sont capturées (utile lors de la phase de développement)

if (!isset($_SESSION['cliID'])) {
	fd_redirige('../index.php');
}

$_GET && fd_exit_session();

$_POST && fdl_control_piratage();

$bd = fd_bd_connect();

$err = isset($_POST['btnEditInfos']) ? fdl_edit_infos($bd) : array(); 

fd_html_debut('BookShop | Mon compte', '../styles/bookshop.css');

fd_bookshop_enseigne_entete(true,'../');

fdl_contenu($bd, $err);

fd_bookshop_pied('../');

fd_html_fin();

ob_end_flush();

/**
 *	Affichage du contenu de la page (compte personnel)
 *	@param  Connexion $bd 	connexion à la base de données
 *	@param 	array	  $err	tableau d'erreurs à afficher
 */
function fdl_contenu($bd, $err) {
	if ($_POST) {
		$infos = array();
		$nb_err = count($err);
		
		//Récupération des données depuis le formumaire soumis
		$infos['cliNomPrenom'] = $_POST['nomprenom'];
		$infos['cliEmail'] = $_POST['email'];
		$infos['cliAdresse'] = $_POST['adresse'];
		$infos['cliCP'] = $_POST['code_postal'];
		$infos['cliVille'] = $_POST['ville'];
		$infos['cliPays'] = $_POST['pays'];
		$infos['currEmail'] = $nb_err > 0 ? $_POST['current_email'] : $_POST['email'];
		
		if ($nb_err > 0) {
			echo '<p class="erreur">Votre inscription n\'a pas pu être réalisée à cause des erreurs suivantes : ';
			foreach ($err as $v) {
				echo '<br> - ', $v;
			}
			echo '</p>';	
		} else {
			echo '<p class="valid">Vos informations ont été modifiées avec succès</p>';
		}
	} else {
		$id = $_SESSION['cliID'];
	
		//Extraction des informations client
		$sql = "SELECT cliEmail, cliNomPrenom, cliAdresse, cliCP, cliVille, cliPays
				FROM clients
				WHERE cliID = $id";
			
		$res = mysqli_query($bd, $sql) or fd_bd_erreur($bd, $sql);
	
		$infos = mysqli_fetch_assoc($res);
	
		mysqli_free_result($res);
		
		if ($infos['cliCP'] == 0) { 
			//Un code postal à 0, indique que l'utilisateur n'a pas encore renseigné son adresse
			$infos['cliAdresse'] = '';
			$infos['cliCP'] = '';
			$infos['cliVille'] = '';
			$infos['cliPays'] = '';
		}
		
		$infos['currEmail'] = $infos['cliEmail'];
	}
	
	echo 
		'<h1>Votre compte</h1>',
		'<h2>Vos commandes passées</h2>',
			'<form action="recapCommande.php" method="post">',			
                '<p class="centered">', fd_form_input(FD_Z_SUBMIT,'btnRecapCommande', 'Commandes'), '</p>',
            '</form>',
		'<h2>Modifier vos informations</h2>',
		'<form method="post" action="compte.php">',
			fd_form_input(FD_Z_HIDDEN, 'current_email', $infos['currEmail']),
			'<p>Vous pouvez changer ici les informations liées à votre compte. </p>',
			'<table>',
				fd_form_ligne('Adresse email :', fd_form_input(FD_Z_TEXT, 'email', $infos['cliEmail'], 30)),
				fd_form_ligne('Changer de mot de passe :', fd_form_input(FD_Z_PASSWORD, 'pass1', '', 30)),
				fd_form_ligne('Répétez le nouveau mot de passe :', fd_form_input(FD_Z_PASSWORD, 'pass2', '', 30)),
				fd_form_ligne('Nom et prénom :', fd_form_input(FD_Z_TEXT, 'nomprenom', $infos['cliNomPrenom'], 30)),
				fd_form_ligne('Numéro et rue :', fd_form_input(FD_Z_TEXT, 'adresse', $infos['cliAdresse'], 30)),
				fd_form_ligne('Code postal :', fd_form_input(FD_Z_TEXT, 'code_postal', $infos['cliCP'], 30)),
				fd_form_ligne('Ville :', fd_form_input(FD_Z_TEXT, 'ville', $infos['cliVille'], 30)),
				fd_form_ligne('Pays :', fd_form_input(FD_Z_TEXT, 'pays', $infos['cliPays'], 30)),
				'<tr><td colspan="2" style="padding-top: 10px;" class="centered">', fd_form_input(FD_Z_SUBMIT,'btnEditInfos','Modifier'), '</td></tr>',
			'</table>',
		'</form>';
		
		mysqli_close($bd);
}

/**
 * Objectif : détecter les tentatives de piratage
 *
 * Si une telle tentative est détectée, la session est détruite et l'utilisateur est redirigée
 * vers la page d'accueil du site
 *
 * @global  array     $_POST
 *
 */
function fdl_control_piratage(){
    $nb = count($_POST);
    if ($nb == 10){
		(! isset($_POST['current_email'])) && fd_exit_session();
        (! isset($_POST['btnEditInfos']) || $_POST['btnEditInfos'] != 'Modifier') && fd_exit_session();
        (! isset($_POST['email'])) && fd_exit_session();
        (! isset($_POST['pass1'])) && fd_exit_session();
        (! isset($_POST['pass2'])) && fd_exit_session();
        (! isset($_POST['nomprenom'])) && fd_exit_session();
        (! isset($_POST['adresse'])) && fd_exit_session();
        (! isset($_POST['code_postal'])) && fd_exit_session();
        (! isset($_POST['ville'])) && fd_exit_session();
        (! isset($_POST['pays'])) && fd_exit_session();
        
        return;     // => ok, pas de problème détecté
    }
    fd_exit_session();
}

/**
 * Vérification qu'une adresse incomplète n'ait pas été entrée
 *
 *
 * @global array $_POST
 *
 */
function fdl_adress_is_full_or_empty($adresse, $ville, $pays, $code_postal) {
	return ($adresse != '' && $code_postal != '' && $ville != '' && $pays != '') //soit tout
		|| ($adresse == '' && $code_postal == '' && $ville == '' && $pays == ''); //soit rien
}



/**
 *	Traitement de la modification des informations
 *
 *		Etape 1. vérification de la validité des données
 *					-> return des erreurs si on en trouve
 *		Etape 2. enregistrement des modifications
 *
 * @global  array     $_POST
 * @param   Connexion $bd	 Connexion à la base de données
 *
 * @return array 	tableau assosiatif contenant les erreurs
 */
function fdl_edit_infos($bd) {
	
	$err = array();
	
	$current_email = trim($_POST['current_email']);
	$email = trim($_POST['email']);
	$pass1 = trim($_POST['pass1']);
	$pass2 = trim($_POST['pass2']);
	$nomprenom = trim($_POST['nomprenom']);
	$adresse = trim($_POST['adresse']);
	$ville = trim($_POST['ville']);
	$pays = trim($_POST['pays']);
	$code_postal = trim($_POST['code_postal']);
	
	// vérification email
    $noTags = strip_tags($email);
    if ($noTags != $email){
        $err['email'] = 'L\'email ne peut pas contenir de code HTML.';
    }
    else {
        $i = mb_strpos($email, '@', 0, 'UTF-8');
        $j = mb_strpos($email, '.', 0, 'UTF-8');
        if ($i === FALSE || $j === FALSE){
            $err['email'] = 'L\'adresse email ne respecte pas le bon format.';	
        }
        // le test suivant rend inutile celui qui précède
        else if (! filter_var($email, FILTER_VALIDATE_EMAIL)){
            $err['email'] = 'L\'adresse email ne respecte pas le bon format.';
        }
    }
	
	// vérification des mots de passe
	if ($pass1 != $pass2) {
		$err['pass1'] = 'Les mots de passe doivent être identiques.';	
	}
	else {
		$nb_pass = mb_strlen($pass1, 'UTF-8');
        $noTags = strip_tags($pass1);
        if (mb_strlen($noTags, 'UTF-8') != $nb_pass) {
            $err['pass1'] = 'La zone Mot de passe ne peut pas contenir de code HTML.';
		}
        else if ($nb_pass != 0 && $nb_pass < 4 || $nb_pass > 20){
            $err['pass1'] = 'Le mot de passe doit être constitué de 4 à 20 caractères.';
        }
			
	}
	
	// vérification des noms et prenoms
	$noTags = strip_tags($nomprenom);
    if ($noTags != $nomprenom){
        $err['nomprenom'] = 'Le nom et le prénom ne peuvent pas contenir de code HTML.';
    }
    else if (empty($nomprenom)) {
		$err['nomprenom'] = 'Le nom et le prénom doivent être renseignés.';	
    }
    else if (mb_regex_encoding ('UTF-8') && ! mb_ereg_match("^[[:alpha:]][[:alpha:]\- ']{1,99}$", $nomprenom)) {
        $err['nomprenom'] = 'Le nom et le prénom ne sont pas valides.';
    }
	
	$full_adress = false;
	// vérification de l'adresse : l'adresse donnée doit être complète, ou non renseignée
	if (!fdl_adress_is_full_or_empty($adresse, $ville, $pays, $code_postal)) {
		$err['adresse_complete'] = 'Vous devez renseigner tous les champs de l\'adresse.';
	} else {
		if ($adresse != '') { 
			//Si l'un existe, alors tous existent
			$full_adress = true;
		}
	}
	
	
	if ($full_adress) {
		// vérification de l'adresse (numéro et rue)
		$noTags = strip_tags($adresse);
		if ($noTags != $adresse){
			$err['adresse'] = 'L\'adresse ne peut pas contenir de code HTML.';
		}
		
		// vérification du code postal
		$noTags = strip_tags($code_postal);
		if ($noTags != $code_postal){
			$err['code_postal'] = 'Le code postal ne peut pas contenir de code HTML.';
		}
		else if (mb_regex_encoding ('UTF-8') && ! mb_ereg_match("^[[:alnum:]\-]{1,99}$", $code_postal)) {
			$err['code_postal'] = 'Le code postal n\'est pas valide.';
		}
		
		// vérification de la ville
		$noTags = strip_tags($ville);
		if ($noTags != $ville){
			$err['ville'] = 'La ville ne peut pas contenir de code HTML.';
		}
		else if (mb_regex_encoding ('UTF-8') && ! mb_ereg_match("^[[:alpha:]][[:alpha:]\- ']{1,99}$", $ville)) {
			$err['ville'] = 'La ville n\'est pas valide.';
		}
		
		// vérification du pays
		$noTags = strip_tags($pays);
		if ($noTags != $pays){
			$err['pays'] = 'Le pays ne peut pas contenir de code HTML.';
		}
		else if (mb_regex_encoding ('UTF-8') && ! mb_ereg_match("^[[:alpha:]][[:alpha:]\- ']{1,99}$", $pays)) {
			$err['pays'] = 'Le pays n\'est pas valide.';
		}
	}
	
	if (count($err) == 0) {
		if ($email != $current_email) { //On ne modifie l'adresse que si elle est différente de celle actuelle, afin d'éviter une requête de test superflue
			$email = fd_bd_protect($bd, $email);
			$sql = "SELECT cliID FROM clients WHERE cliEmail = '$email'"; 
			
			$res = mysqli_query($bd,$sql) or fd_bd_erreur($bd,$sql);
			
			if (mysqli_num_rows($res) != 0) {
				$err['email'] = 'L\'adresse email spécifiée existe déjà.';
			}
			// libération des ressources 
			mysqli_free_result($res);
		}
	}
	
	// s'il y a des erreurs ==> on retourne le tableau d'erreurs	
	if (count($err) > 0) { 	
		return $err;	
	}
	
	// pas d'erreurs ==> enregistrement des données modifiées pour l'utilisateur
	$nomprenom = fd_bd_protect($bd, $nomprenom);
	
	$id = $_SESSION['cliID'];
	
	$sql = "UPDATE clients
			SET cliNomPrenom = '$nomprenom'";
	
	if ($nb_pass > 0) {
		$pass = fd_bd_protect($bd, md5($pass1));
		$sql .= ",
				cliPassword = '$pass'";
	}
	
	if ($full_adress) {
		$adresse = fd_bd_protect($bd, $adresse);
		$ville = fd_bd_protect($bd, $ville);
		$pays = fd_bd_protect($bd, $pays);
		$code_postal = fd_bd_protect($bd, $code_postal);
		
		$sql .= ",
				 cliAdresse = '$adresse',
				 cliVille = '$ville',
				 cliPays = '$pays',
				 cliCP = '$code_postal'";
	}
	if ($email != $current_email) {
		//Modification de l'email uniquement si elle est différente de l'ancienne, afin d'éviter les tentatives de piratages
		//(puisqu'il n'y a pas de vérification de $email si $email == $actual_email)
		
		$sql .= ",
				 cliEmail = '$email'";
	}
	
	$sql .= " WHERE cliID = $id";
            
	mysqli_query($bd, $sql) or fd_bd_erreur($bd, $sql);
}
?>