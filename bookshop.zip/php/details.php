<?php
ob_start('ob_gzhandler'); //démarre la bufferisation, compression du tampon si le client supporte gzip
session_start();    // Lancement de la session

require_once '../php/bibli_generale.php';
require_once '../php/bibli_bookshop.php';

$db = fd_bd_connect();
$correct_search = false;

if (count($_POST) != 0 && (isset($_POST['addToCart']) || isset($_POST['mod']) || isset($_POST['suppr'])) && isset($_POST['id'])) {
	add_to_cart($db);
}


if (isset($_POST['addToWishlist']) || isset($_POST['removeFromWishlist'])) {
	$cliID = $_SESSION['cliID'];
	$liID = fd_bd_protect($db, $_POST['id']);
	if (isset($_POST['addToWishlist'])) {
		fd_add_to_wishlist($db, $cliID, $liID);
	} else {
		fd_remove_from_wishlist($db, $cliID, $liID);
	}
}

if (count($_GET) == 1 && isset($_GET['article']) && is_numeric($_GET['article'])) {
	$sql = 'SELECT liID, liTitre, edNom, edWeb, liPrix, liPages, liISBN13, liResume, auNom, auPrenom
				FROM livres, editeurs, aut_livre, auteurs
				WHERE liIDEditeur = edID
				AND liID = al_IDLivre
				AND al_IDAuteur = auID
				AND liID = ' . $_GET['article'] . ';';
				
	$res = mysqli_query($db, $sql) or fd_bd_erreur($db, $sql);

	$ret = transform_res($db, $res);

	mysqli_free_result($res);
	
	$correct_search = true;
}

error_reporting(E_ALL); // toutes les erreurs sont capturées (utile lors de la phase de développement)

fd_html_debut('BookShop | Détails', '../styles/bookshop.css');

fd_bookshop_enseigne_entete(isset($_SESSION['cliID']),'../');

if ($correct_search) {
	if (empty($ret)) {
		echo '<p class="error">Ce livre n\'existe pas.</p>';
	} else {
		foreach ($ret as $item) {
			fd_afficher_livre($item, 'details', '../');
		}
	}
} else {
	echo '<p class="error">La demande n\'est pas correcte.</p>';
}

fd_bookshop_pied('../');

fd_html_fin();

mysqli_close($db);

ob_end_flush();

?>