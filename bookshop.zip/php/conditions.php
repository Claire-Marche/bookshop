<?php
ob_start('ob_gzhandler'); //démarre la bufferisation, compression du tampon si le client supporte gzip
session_start();    // Lancement de la session

require_once '../php/bibli_generale.php';
require_once '../php/bibli_bookshop.php';

error_reporting(E_ALL); // toutes les erreurs sont capturées (utile lors de la phase de développement)

fd_html_debut('BookShop | Conditions', '../styles/bookshop.css');

fd_bookshop_enseigne_entete(isset($_SESSION['cliID']),'../');

fdl_contenu();

fd_bookshop_pied('../');

fd_html_fin();

ob_end_flush();

/**
 *	Affichage du contenu de la page
 */
function fdl_contenu() {
	echo '<h1>Conditions d\'utilisation</h1>',
		  '<p>Ce site est accessible gratuitement à tout utilisateur disposant d\'un accès à internet. Tous les coûts afférents à l\'accès au Service, que ce soient les frais matériels, logiciels ou d\'accès à internet sont exclusivement à la charge de l\'utilisateur. Il est seul responsable du bon fonctionnement de son équipement informatique ainsi que de son accès à internet. Certaines sections du site sont réservées aux membres. </p>',
		  '<p>Dans une logique de respect de la vie privée de ses Utilisateurs, la collecte et le traitement des données personnelles, effectués au sein du présent site, sont effectués conformément à la loi n°78-17 du 6 janvier 1978 relative à l\'informatique, aux fichiers et aux libertés, dite Loi "Informatique et Libertés" telle que modifiée en 2004. Conformément à l\'article 34 de la loi "Informatique et Libertés", l\'utilisateur possède un droit d\'opposition, d\'accès, de rectification et de suppression sur les données personnelles le concernant.</p>';
}
?>